
    <div class="footer center">
        <img src="../images/Rock-Dudes-Logo.webp" alt="Company Logo" class="img-respond-small">
        <p style="font-size:13px;">Want to be updated when new products are posted? <a style="font-size:13px" href="join-maillist.php">Sign up</a> for updates and newsletters! <br> Any Questions? Contact us at <?php echo Client_Email;?><br>
            <br>Background credit to Rifat Ahmmed on <a style="font-size:13px" href="https://www.vecteezy.com/">vecteezy.com</a><br>
            Icons by rawpixel.com on Freepik
        </p>
    </div>
    <!--Footer Ends-->
    </body>
    
</html>
