
<!-- Admin footer logo and copyright info: --> 
    
    <div class="footer"> 
        <div class="wrapper">
        <p class="text-center">
            2023 All Rights Reserved, Rock Site. Developed by Caden Conde & Eric Bucher<br><br>
            <div> Icons made by Freepik, Phoenix Group, cahiwak, Hilmy Abiyyu A., Dragon Icons, & Maxim Basinski Premium from <a href="https://www.flaticon.com/" title="Flaticon">www.flaticon.com'</a></div>
        </p>
        </div>
    </div>
</body>
</html>